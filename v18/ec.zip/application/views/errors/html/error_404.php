<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>404 Page Not Found</title>
<link rel="stylesheet" type="text/css" href="./res/css/anim.css">
<style type="text/css">
        body{
          user-select:none;
          touch-action:manipulation;
        }
</style>
</head>

<body>
	<div style="width:100vw;height:100vh;    position: fixed;
    top: 0px;
    left: 0px;
    margin-top: 0px;
    margin-left: 0px;">
		<h1 style="font-family: sans-serif;font-size:25vh;margin-bottom:0px;margin-left:20%;color:blue;">404 <text style="font-size: 10vh;
    color: red;
    font-family: monospace;"> Error</text></h1>
		<h2 style="font-family: sans-serif;margin-left:20%;">Page Not Found</h2>
		<h3 style="font-family: sans-serif;margin-left:20%;">The page you requested was not found.</h3>
		<text></text>
	</div>
</body>
</html>