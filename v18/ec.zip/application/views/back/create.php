<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="<?=base_url()?>index.php/Adminlogin/create" method="post">
	<input required="required" type="text" name="aname"><br><br>
	<input required="required" type="password" name="apass"><br><br>
	<button type="submitt">Go</button>
</form>

</body>
</html>